package com.example.dg_ornascan_apk;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
